﻿using Prism.Events;

namespace NewWorldCompanion.Events
{
    public class OcrTextReadyEvent : PubSubEvent
    {
    }
    public class OcrTextCountReadyEvent : PubSubEvent
    {
    }
}